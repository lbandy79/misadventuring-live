# Songoku 

A Pen created on CodePen.

Original URL: [https://codepen.io/lbandy79/pen/bNeVyya](https://codepen.io/lbandy79/pen/bNeVyya).

Songoku pixel art by css3 